import { render, screen } from '@testing-library/react';
import { afterEach, expect, test, vi } from 'vitest';
import App from './App';

afterEach(() => vi.restoreAllMocks());

test('shows dynamic renewal summary and rows', async () => {
  const opportunity = {
    entId:'ENT-1', sku:'VLT-SRV', qty:1, customerName:'ABC Tech', accountId:'A1', owner:'Owner', segment:'ENT',
    endDate:'2026-12-15', renewalStatus:'open', matchMethod:'CRM_NAME', matchConfidence:'HIGH', flags:[],
    quote:{ quoteCurrency:'USD', totalLocal:2400, totalUsd:2400, termMonths:12, discountPercent:0, reinstatementPercent:0, quoteSku:'VLT-SRV', explanation:'', quotable:true },
    rankingScore:120, rankingReason:'Top',
  };

  vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
    const url = String(input);
    if (url.includes('/chase-list')) return new Response(JSON.stringify([{ entId:'ENT-1' }]));
    return new Response(JSON.stringify([opportunity]));
  });

  render(<App />);

  expect(await screen.findByText('VAULT RENEWAL OPPORTUNITIES')).toBeInTheDocument();
  expect(screen.getByText('ABC Tech')).toBeInTheDocument();
  expect(screen.getByText('VLT-SRV')).toBeInTheDocument();
  expect(screen.getByText('$2,400')).toBeInTheDocument();
  expect(screen.getByText(/Total Opportunities:/)).toHaveTextContent('Total Opportunities: 1');
  expect(screen.getByRole('checkbox', { name:/Show Top 10 Chase List Only/i })).not.toBeChecked();
});
