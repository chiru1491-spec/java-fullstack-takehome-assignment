import { useEffect, useState } from 'react';

type Quote = { quoteCurrency:string; totalLocal:number; totalUsd:number; termMonths:number; discountPercent:number; reinstatementPercent:number; quoteSku:string|null; explanation:string; quotable:boolean };
type Opportunity = { entId:string; sku:string; qty:number; customerName:string; accountId:string|null; owner:string|null; segment:string|null; endDate:string; renewalStatus:string; matchMethod:string; matchConfidence:string; flags:string[]; quote:Quote; rankingScore:number; rankingReason:string };
type Chase = { entId:string; customerName:string; sku:string; qty:number; endDate:string; score:number; reason:string; renewalStatus:string; owner:string|null; accountId:string|null };

function formatDate(value:string) {
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'2-digit' }).replace(/ /g,'-');
}

function quoteDisplay(row:Opportunity) {
  if (!row.quote.quotable) return '-';
  return `$${row.quote.totalUsd.toLocaleString('en-US', { maximumFractionDigits:2 })}`;
}

export default function App() {
  const [rows,setRows]=useState<Opportunity[]>([]);
  const [chase,setChase]=useState<Chase[]>([]);
  const [onlyChase,setOnlyChase]=useState(false);
  const [error,setError]=useState<string|null>(null);

  useEffect(() => {
    Promise.all([
      fetch('/api/opportunities').then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))),
      fetch('/api/opportunities/chase-list').then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))),
    ]).then(([opps,list]) => { setRows(opps); setChase(list); })
      .catch(e => setError(e.message));
  }, []);

  const counts = {
    open: rows.filter(r => r.renewalStatus === 'open').length,
    renewed: rows.filter(r => r.renewalStatus === 'renewed').length,
    inFlight: rows.filter(r => r.renewalStatus === 'in flight' || r.renewalStatus === 'partially renewed').length,
    cannotQuote: rows.filter(r => r.flags.includes('CANNOT_QUOTE') || !r.quote.quotable).length,
  };

  const chaseIds = new Set(chase.map(x => x.entId));
  const visible = onlyChase ? rows.filter(r => chaseIds.has(r.entId)).slice(0, 10) : rows;

  return (
    <main style={{ maxWidth:900, margin:'32px auto', fontFamily:'monospace', color:'#e8e8e8', background:'#111', padding:'24px 28px', border:'1px solid #333', boxSizing:'border-box' }}>
      <header style={{ textAlign:'center', borderBottom:'1px solid #777', paddingBottom:'12px', marginBottom:'14px' }}>
        <div>---------------------------------------------------------------</div>
        <h1 style={{ margin:'8px 0', fontSize:'clamp(16px, 3vw, 22px)', letterSpacing:'1px' }}>VAULT RENEWAL OPPORTUNITIES</h1>
        <div>---------------------------------------------------------------</div>
      </header>

      <section style={{ margin:'18px 0', lineHeight:'1.8' }}>
        <div>Total Opportunities: {rows.length}</div>
        <div>Open: {counts.open}</div>
        <div>Renewed: {counts.renewed}</div>
        <div>In Flight: {counts.inFlight}</div>
        <div>Cannot Quote: {counts.cannotQuote}</div>
      </section>

      <label style={{ display:'inline-block', marginBottom:'18px', cursor:'pointer' }}>
        <input type="checkbox" checked={onlyChase} onChange={e => setOnlyChase(e.target.checked)} /> Show Top 10 Chase List Only
      </label>

      {error && <p role="alert" style={{ color:'#ff9a9a' }}>API error: {error}</p>}

      <div style={{ overflowX:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', tableLayout:'fixed' }}>
          <thead>
            <tr style={{ borderBottom:'1px solid #777', borderTop:'1px solid #777' }}>
              {['Customer','SKU','End Date','Status','Quote'].map(h => (
                <th key={h} style={{ textAlign:h === 'Quote' ? 'right' : 'left', padding:'10px 6px' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map(row => (
              <tr key={row.entId}>
                <td style={{ padding:'8px 6px' }}>{row.customerName}</td>
                <td style={{ padding:'8px 6px' }}>{row.sku}</td>
                <td style={{ padding:'8px 6px' }}>{formatDate(row.endDate)}</td>
                <td style={{ padding:'8px 6px' }}>{row.flags.includes('CANNOT_QUOTE') ? 'CANNOT QUOTE' : row.renewalStatus === 'in flight' ? 'IN FLIGHT' : row.renewalStatus.toUpperCase()}</td>
                <td style={{ padding:'8px 6px', textAlign:'right' }}>{quoteDisplay(row)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {!error && rows.length === 0 && <p>No opportunities found.</p>}
    </main>
  );
}
