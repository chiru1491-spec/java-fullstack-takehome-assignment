# Takehome Test: starter repo

This repo is plumbing only. It builds, runs and connects to the database so you can spend your time on the problem. There are no tables, no data loading and no domain code. Designing those is part of the exercise.

Replace this README with your own when you submit. Keep the run and test commands to three or fewer.

## Run everything

```
docker compose up --build
```

- Frontend: http://localhost:5173
- API health check: http://localhost:8080/api/health
- Postgres: `localhost:5432`, database, user and password all `renewals`

## Run the backend on your machine instead

```
docker compose up -d db
cd backend && ./mvnw spring-boot:run
cd frontend && npm install && npm run dev
```

## Run the tests

```
cd backend && ./mvnw test      # needs Docker running (Testcontainers starts a throwaway Postgres)
cd frontend && npm install && npm test
```

## Troubleshooting

- **Port 5432 already in use:** run `DB_PORT=55432 docker compose up --build`. Only the host port changes; the backend still reaches the database inside Docker.
- **Testcontainers cannot find Docker (Colima, Rancher Desktop):** export `DOCKER_HOST` to your runtime's socket and set `TESTCONTAINERS_DOCKER_SOCKET_OVERRIDE=/var/run/docker.sock`. For Colima: `export DOCKER_HOST=unix://$HOME/.colima/default/docker.sock`.

## What is here

| Path | What it is |
|---|---|
| `data/` | The data pack. Do not edit these files. Mounted read-only at `/data` in Docker. |
| `backend/` | Java 21, Spring Boot 3, Flyway, Postgres driver, JDBC. Add JPA, jOOQ or anything else you prefer. |
| `backend/.../config/ClockConfig.java` | A `Clock` bean fixed to `app.today` (2026-11-10). Inject it; never call `LocalDate.now()` without it. |
| `backend/.../config/AppProperties.java` | `app.today` and `app.data-dir` from `application.yml`. |
| `backend/src/main/resources/db/migration/` | Flyway migrations. `V1__init.sql` is empty. |
| `backend/src/test/.../HealthEndpointTest.java` | A working Testcontainers integration test to copy from. |
| `frontend/` | React 18, TypeScript, Vite, Vitest. `/api` is proxied to the backend. |
| `DECISIONS.md`, `AI_USAGE.md` | Empty templates for the required notes. |

You may change anything here, including the structure. If you do, say so in `DECISIONS.md`.
