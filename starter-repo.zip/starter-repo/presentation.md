# Renewals Chase List

## 1. Problem
The team needs genuine December 2026 renewals, defensible quotes, and a prioritised chase list despite conflicting vendor, CRM, order and policy sources.

## 2. Decisions that mattered
- Match first by vendor account number, then merged/normalised CRM name and email domain.
- Accepted orders renew; rejected/cancelled orders leave open; submitted orders are in flight; partial accepted quantity is partially renewed.
- Quote only entitlements in the 2026-11-10 to 2027-02-08 window; use the November FX rate and effective quote-date price.
- Use 12-month term for the list, legacy successors, 20% reinstatement over 30 days, and no >180-day lapsed renewals.

## 3. Evidence and assumptions
The data exposes explicit vendor numbers, accepted/cancelled orders and effective-dated price rows. Missing successor or FX data is handled as unquotable rather than guessed.

## 4. Trade-offs
We did not implement co-term or 24/36-month choices because the chase quote default is 12 months. This can be changed when the sales team requests multi-year terms. We use whole-list ranking rather than a CRM-specific score.

## 5. Open questions
- Finance: multi-year discount application for VLT-SRV after October.
- Sales: co-term common date and whether partial renewals should be ranked separately.
- Ops: missing backfills, especially 70014 and 70018.

## 6. Chase list
Ranking uses days to expiry, quote value, account segment and order state. Entries already renewed or churned are excluded. Unmatched, low-confidence and legacy rows are excluded or flagged.

## 7. Next week
Add co-term groups, complete account backfill, test the whole data pack against a frozen expected result, and improve presentation and API evidence.
