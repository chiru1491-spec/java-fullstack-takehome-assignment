# AI usage

## Tools and what I used them for
- GitHub Copilot: repository implementation, data modelling, reconciliation/quote logic, React table, tests and documentation.
- I used AI to create first drafts and compile repetitive code, then inspected data and decisions manually.

## Where the AI was wrong, or guessed when it should have asked
- It initially used `/api/opportunities` as if no backend data loader existed; I replaced this with an explicit startup loader and Flyway schema.
- It treated all legacy SKUs as renewable; I corrected this to require a successor where the price book provides one.
- It used Java `toLower` and `toLower()` typos; I corrected these to `toLowerCase()` and recompilation verification.
- It initially described co-terming as complete; the implementation only preserves/flags co-term order evidence and does not yet create a fully unified quote group.

## Decisions I made without the tool
- Exact matching precedence: vendor account number, then CRM name/trading name, then email domain.
- ACCEPTED/SUBMITTED/REJECTED/CANCELLED status semantics.
- 12-month chase default and the 2026-11-10 fixed quote-date policy.
- Top-10 ranking weights and exclusion rules.
