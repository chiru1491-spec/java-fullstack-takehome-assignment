# Decisions

## D1. Renewal window
- **Options:** Use vendor end-date window directly, or include grace/lapsed ranges.
- **Choice:** Include every entitlement with end date from 2026-11-10 through 2027-02-08 inclusive. Also preserve rows lapsed within 180 days as quotable after reinstatement, subject to the same window rule.
- **Why:** This follows the brief exactly and prevents silent expansion beyond the chase window.

## D2. Matching CRM accounts
- **Options:** Match on typed names, account number, email domain, or combination.
- **Choice:** Vendor account number first (HIGH), normalised name/trading name second (MEDIUM), then email domain (MEDIUM). Unmatched is LOW.
- **Why:** Ops explicitly identified vendor account number as the preferred key and warned that names are reseller-typed.

## D3. Merged and churned accounts
- **Options:** Keep history IDs or redirect to surviving records.
- **Choice:** Redirect MERGED accounts to `merged_into`; Blue Harbour therefore belongs to Granite Peak. CHURNED accounts are never chased or quoted.
- **Why:** The CRM and Slack indicate acquisition/consolidation and an Amber Valley competitor move.

## D4. Order interpretation
- **Options:** Treat any order or only accepted orders as renewal evidence.
- **Choice:** ACCEPTED renews/partially renews by accepted quantity. SUBMITTED is in flight. REJECTED/CANCELLED leave open for rework. Vendor export lag is resolved in favour of accepted orders.
- **Why:** Ying Lim states accepted orders renew despite stale vendor exports.

## D5. Commercial quote
- **Options:** Use last paid price, 2026/2027 effective price, or quote-date price.
- **Choice:** Use the price effective on 2026-11-10. Add 20% only for lapsed entitlements >30 days; treat >180 days as cannot quote. Legacy SKUs use successor SKU where available.
- **Why:** Memo, Slack and effective-dated book. Last paid price is explicitly reference-only.

## D6. FX
- **Options:** Use current market FX or supplied monthly FX.
- **Choice:** Use November 2026 supplied rate. Hong Kong uses USD and no conversion.
- **Why:** Marcus explicitly says to use quote-month supplied rates.

## D7. Term, discount and January price
- **Options:** Default to 12, 24 or 36 months and choose January price or quote-date price.
- **Choice:** Default 12-month quotes for the chase list. 24/36 discounts are recorded for future use but not automatically chosen in this view. Use quote-date November 2026 price even though January renewals later move to January price.
- **Why:** The materials establish January uplift, but the quote date is November and the memo does not say to pre-apply January.

## D8. Ranking
- **Options:** Rank by due date, value, segment, or combined score.
- **Choice:** Combined score: urgency 100 minus days remaining plus small quote-value weight, plus ENT/MID segment and partial/in-flight adjustments. Renewed, churned and unquotable rows score zero and are excluded.
- **Why:** This balances imminence with economic value and account tier while keeping the result reproducible.

## Open questions
- Sales/Finance: 24/36-month quoting and how 36-month withdrawal applies to VLT-SRV.
- Sales: co-term common date for groups within 90 days.
- Ops: vendor account backfill for null-account CRM rows.
- Finance: whether reinstatement applies to partial accepted quantities.
- Default applied meanwhile: 12-month quote, quote-date price, November FX, 20% reinstatement over 30 days, legacy successor quote only when successor exists, and no quote over 180 days.

## Not done
- Full 24/36-month term selection UI.
- Co-term line grouping beyond flags.
- PDF presentation generation; `presentation.md` is provided.
