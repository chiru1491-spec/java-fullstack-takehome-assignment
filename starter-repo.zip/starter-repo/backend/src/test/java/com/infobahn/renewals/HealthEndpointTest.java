package com.infobahn.renewals;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

/** Starts the full app against a throwaway Postgres. Requires Docker. Use it as a template for integration tests. */
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class HealthEndpointTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");

    @Autowired
    TestRestTemplate http;

    @Test
    void reportsFixedDateDatabaseAndDataFolder() {
        @SuppressWarnings("unchecked")
        Map<String, Object> body = http.getForObject("/api/health", Map.class);

        assertThat(body).containsEntry("status", "ok")
                .containsEntry("today", "2026-11-10")
                .containsEntry("database", "up")
                .containsEntry("dataDirFound", true);
    }
}
