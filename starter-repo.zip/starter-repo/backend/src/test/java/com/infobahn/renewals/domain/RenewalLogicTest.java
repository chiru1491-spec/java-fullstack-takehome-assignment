package com.infobahn.renewals.domain;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.infobahn.renewals.config.AppProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RenewalLogicTest {
    private RenewalService service;
    private DataLoader data;

    @BeforeEach
    void setUp() throws Exception {
        data = new DataLoader(new AppProperties(LocalDate.of(2026,11,10), "."), null, null);
        setData(data);
        service = new RenewalService(data, new AppProperties(LocalDate.of(2026,11,10), "."));
    }

    private void setData(DataLoader d) throws Exception {
        d.accounts = List.of(
            new Models.CrmAccount("ACC-1","Wren Street Bank",null,"Singapore","wrenstreet.example.sg","ENT","A. Ng","ACTIVE",null,"70030",null),
            new Models.CrmAccount("ACC-2","Granite Peak Health Pty Ltd","Granite Peak","Australia","granitepeak.example","ENT","M. Tanaka","ACTIVE",null,null,null));
        d.prices = List.of(
            new Models.PriceRow("VLT-SRV-MNT","VLT-SRV","PERPETUAL_MAINT",LocalDate.of(2026,1,1),LocalDate.of(2026,12,31),new BigDecimal("240.00"),null),
            new Models.PriceRow("VLT-SRV-SUB","VLT-SRV","SUBSCRIPTION",LocalDate.of(2026,1,1),null,new BigDecimal("420.00"),null),
            new Models.PriceRow("VLT-SRV-LGCY","VLT-SRV","LEGACY_PERPETUAL",LocalDate.of(2025,1,1),LocalDate.of(2026,6,30),new BigDecimal("130.00"),"VLT-SRV-SUB"));
        d.fx = List.of(new Models.FxRate("2026-11","SGD",new BigDecimal("0.760")));
    }

    @Test
    void matchesVendorAccountBeforeName() {
        Models.Entitlement e = ent("V-1","VLT-SRV-MNT",70030,"SGD","Wren Street Bank","Singapore");
        assertThat(service.match(e).confidence()).isEqualTo("HIGH");
        assertThat(service.match(e).method()).isEqualTo("VENDOR_ACCOUNT");
    }

    @Test
    void acceptedFullOrderMarksRenewedAndPartialMarksPartial() {
        Models.Entitlement e = ent("V-1","VLT-SRV-MNT",70030,"SGD","Wren Street Bank","Singapore");
        Models.Order full = order("O-1","V-1","ACCEPTED",2);
        Models.Order partial = order("O-2","V-1","ACCEPTED",1);
        assertThat(service.interpretOrder(List.of(full),e)).isEqualTo("renewed");
        assertThat(service.interpretOrder(List.of(partial),e)).isEqualTo("partially renewed");
    }

    @Test
    void submittedIsInFlightAndRejectedIsOpen() {
        Models.Entitlement e = ent("V-1","VLT-SRV-MNT",70030,"SGD","Wren Street Bank","Singapore");
        assertThat(service.interpretOrder(List.of(order("O-1","V-1","SUBMITTED",2)),e)).isEqualTo("in flight");
        assertThat(service.interpretOrder(List.of(order("O-1","V-1","REJECTED",2)),e)).isEqualTo("open");
    }

    @Test
    void appliesReinstatementAndNovemberFx() {
        Models.Entitlement e = ent("V-2","VLT-SRV-MNT",70030,"SGD","Wren Street Bank","Singapore");
        e = new Models.Entitlement(e.entId(),e.sku(),e.licenseModel(),2,LocalDate.of(2025,10,1),LocalDate.of(2026,10,1),e.status(),e.customerName(),"SG",e.vendorAccountNo(),e.reseller(),e.contactEmail(),"SGD",e.lastUnitPrice());
        Models.Quote q=service.quote(e,LocalDate.of(2026,11,10));
        assertThat(q.quotable()).isTrue();
        assertThat(q.reinstatementPercent()).isEqualByComparingTo("20");
        assertThat(q.totalUsd()).isEqualByComparingTo("576.00");
    }

    @Test
    void legacySkuCannotBeQuotedAsLegacyAndMoreThan180DaysCannotBeQuoted() {
        Models.Entitlement legacy = new Models.Entitlement("V-L","VLT-SRV-LGCY","LEGACY_PERPETUAL",2,LocalDate.of(2025,1,1),LocalDate.of(2026,12,1),"ACTIVE","Wren Street Bank","SG","70030",null,null,"SGD",null);
        assertThat(service.quote(legacy,LocalDate.of(2026,11,10)).quotable()).isFalse();

        Models.Entitlement old = ent("V-O","VLT-SRV-MNT",70030,"SGD","Wren Street Bank","Singapore");
        old = new Models.Entitlement(old.entId(),old.sku(),old.licenseModel(),2,old.startDate(),LocalDate.of(2026,4,1),old.status(),old.customerName(),"SG",old.vendorAccountNo(),old.reseller(),old.contactEmail(),old.currency(),old.lastUnitPrice());
        assertThat(service.quote(old,LocalDate.of(2026,11,10)).quotable()).isFalse();
    }

    private Models.Entitlement ent(String id,String sku,int account,String currency,String name,String country) {
        return new Models.Entitlement(id,sku,"PERPETUAL_MAINT",2,LocalDate.of(2025,11,1),LocalDate.of(2026,12,1),"ACTIVE",name,country,String.valueOf(account),null,null,currency,BigDecimal.ZERO);
    }
    private Models.Order order(String id,String entId,String status,int qty) {
        return new Models.Order(id,LocalDate.of(2026,10,1),"ACC-1",entId,"VLT-SRV-MNT",qty,12,LocalDate.of(2026,11,1),LocalDate.of(2027,10,31),status,null);
    }
}
