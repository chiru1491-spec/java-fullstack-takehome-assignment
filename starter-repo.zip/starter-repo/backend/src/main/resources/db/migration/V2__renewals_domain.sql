CREATE TABLE IF NOT EXISTS crm_accounts (
    account_id VARCHAR(30) PRIMARY KEY,
    name VARCHAR(300) NOT NULL,
    trading_name VARCHAR(300),
    country VARCHAR(100),
    email_domain VARCHAR(200),
    segment VARCHAR(20),
    owner VARCHAR(100),
    status VARCHAR(20),
    merged_into VARCHAR(30),
    vendor_account_no VARCHAR(30),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS entitlements (
    ent_id VARCHAR(30) PRIMARY KEY,
    sku VARCHAR(50),
    license_model VARCHAR(40),
    qty INTEGER,
    start_date DATE,
    end_date DATE,
    status VARCHAR(20),
    end_customer_name VARCHAR(300),
    end_customer_country VARCHAR(10),
    vendor_account_no VARCHAR(30),
    reseller VARCHAR(100),
    contact_email VARCHAR(300),
    currency VARCHAR(10),
    last_unit_price_local NUMERIC(18,6)
);

CREATE TABLE IF NOT EXISTS orders (
    order_id VARCHAR(30) PRIMARY KEY,
    order_date DATE,
    crm_account_id VARCHAR(30),
    ent_id VARCHAR(30),
    sku VARCHAR(50),
    qty INTEGER,
    term_months INTEGER,
    new_start DATE,
    new_end DATE,
    status VARCHAR(20),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS price_book (
    sku VARCHAR(50),
    description TEXT,
    family VARCHAR(50),
    license_model VARCHAR(40),
    effective_from DATE,
    effective_to DATE,
    list_price_usd_annual NUMERIC(18,6),
    successor_sku VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS fx_rates (
    month VARCHAR(7),
    currency VARCHAR(10),
    usd_per_unit NUMERIC(18,8),
    PRIMARY KEY(month, currency)
);
