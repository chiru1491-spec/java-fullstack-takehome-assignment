
-- Intentionally empty. The schema is yours to design.
-- Add your tables here, or in V2__..., V3__... files.
SELECT 1;
