package com.infobahn.renewals.web;

import com.infobahn.renewals.domain.Models;
import com.infobahn.renewals.domain.RenewalService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RenewalController {
    private final RenewalService renewals;

    public RenewalController(RenewalService renewals) { this.renewals = renewals; }

    @GetMapping("/api/opportunities")
    public List<Models.Opportunity> opportunities() { return renewals.opportunities(); }

    @GetMapping("/api/opportunities/chase-list")
    public List<Models.ChaseEntry> chaseList() { return renewals.chaseList(); }
}
