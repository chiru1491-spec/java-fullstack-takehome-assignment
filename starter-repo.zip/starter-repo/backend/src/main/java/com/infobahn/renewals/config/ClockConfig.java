package com.infobahn.renewals.config;

import java.time.Clock;
import java.time.ZoneOffset;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Inject {@link Clock} wherever you need "today" so tests stay deterministic.
 * Use {@code LocalDate.now(clock)}, never {@code LocalDate.now()}.
 */
@Configuration
public class ClockConfig {

    @Bean
    public Clock clock(AppProperties props) {
        if (props.today() == null) {
            return Clock.systemUTC();
        }
        return Clock.fixed(props.today().atStartOfDay().toInstant(ZoneOffset.UTC), ZoneOffset.UTC);
    }
}
