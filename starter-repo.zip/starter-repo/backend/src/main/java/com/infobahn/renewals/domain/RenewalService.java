package com.infobahn.renewals.domain;

import com.infobahn.renewals.config.AppProperties;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class RenewalService {
    private final DataLoader data;
    private final AppProperties props;

    public RenewalService(DataLoader data, AppProperties props) { this.data=data; this.props=props; }

    public Models.Match match(Models.Entitlement e) {
        for (var a: data.accounts) {
            if (a.vendorAccountNo()!=null && e.vendorAccountNo()!=null && a.vendorAccountNo().equals(e.vendorAccountNo()))
                return resolve(a, "VENDOR_ACCOUNT", "HIGH");
        }
        String vendorName = normalize(e.customerName());
        for (var a: data.accounts) {
            if (normalize(a.name()).equals(vendorName) || (a.tradingName()!=null && normalize(a.tradingName()).equals(vendorName)))
                return resolve(a, "CRM_NAME", "MEDIUM");
        }
        if (e.contactEmail()!=null && e.contactEmail().contains("@")) {
            String domain = e.contactEmail().substring(e.contactEmail().indexOf('@')+1).toLowerCase();
            for (var a: data.accounts) if (domain.equals(a.emailDomain())) return resolve(a, "EMAIL_DOMAIN", "MEDIUM");
        }
        return new Models.Match(null, null, "UNMATCHED", "LOW");
    }

    private Models.Match resolve(Models.CrmAccount a, String method, String confidence) {
        Models.CrmAccount effective=a;
        if ("MERGED".equals(a.status()) && a.mergedInto()!=null)
            effective=data.accounts.stream().filter(x->a.mergedInto().equals(x.accountId())).findFirst().orElse(a);
        return new Models.Match(effective.accountId(), effective.name(), method+("MERGED".equals(a.status())?"_MERGED":""), confidence);
    }

    public String interpretOrder(List<Models.Order> orders, Models.Entitlement e) {
        var related=orders.stream().filter(o->e.entId().equals(o.entId())).toList();
        if (related.stream().anyMatch(o->"ACCEPTED".equals(o.status()))) {
            int acceptedQty=related.stream().filter(o->"ACCEPTED".equals(o.status())).mapToInt(Models.Order::qty).sum();
            if (acceptedQty>=e.qty()) return "renewed";
            if (acceptedQty>0) return "partially renewed";
        }
        if (related.stream().anyMatch(o->"SUBMITTED".equals(o.status()))) return "in flight";
        if (related.stream().anyMatch(o->"REJECTED".equals(o.status())||"CANCELLED".equals(o.status()))) return "open";
        return "open";
    }

    public Models.Quote quote(Models.Entitlement e, LocalDate today) {
        Models.Match match=match(e); Models.CrmAccount account=account(match.accountId());
        if (account != null && "CHURNED".equals(account.status()))
            return unquotable(e.currency(), "Do not quote: CRM account is marked CHURNED");
        if ("LEGACY_PERPETUAL".equals(e.licenseModel()) || e.sku().endsWith("LGCY")) {
            var successor=data.prices.stream().filter(p->p.sku().equals(e.sku())&&active(p,today)).findFirst();
            String why=successor.flatMap(p->Optional.ofNullable(p.successorSku())).orElse(null);
            if (why==null) return unquotable(e.currency(), "Cannot quote legacy SKU: no successor SKU defined");
        }
        long daysPast=ChronoUnit.DAYS.between(e.endDate(), today);
        if (daysPast>180) return unquotable(e.currency(), "Cannot quote: entitlement lapsed more than 180 days");

        String quoteSku=successorSku(e.sku(), today);
        var price=data.prices.stream().filter(p->p.sku().equals(quoteSku)&&active(p,today)).findFirst();
        if (price.isEmpty()) return unquotable(e.currency(), "Cannot quote: no effective price for "+quoteSku);
        var fx=data.fx.stream().filter(r->r.currency().equals(e.currency())&&r.month().equals(today.toString().substring(0,7))).findFirst();
        if (!"USD".equals(e.currency()) && fx.isEmpty()) return unquotable(e.currency(), "Cannot quote: no November FX rate for "+e.currency());

        int term=12; BigDecimal discount=BigDecimal.ZERO; BigDecimal reinstate=BigDecimal.ZERO;
        if (daysPast>30) reinstate=new BigDecimal("20");
        BigDecimal usd=price.get().annualUsd().multiply(BigDecimal.valueOf(e.qty())).multiply(BigDecimal.valueOf(term)).divide(BigDecimal.valueOf(12),6,RoundingMode.HALF_UP);
        usd=usd.multiply(BigDecimal.ONE.subtract(discount.divide(BigDecimal.valueOf(100),6,RoundingMode.HALF_UP)));
        usd=usd.multiply(BigDecimal.ONE.add(reinstate.divide(BigDecimal.valueOf(100),6,RoundingMode.HALF_UP))).setScale(2,RoundingMode.HALF_UP);

        BigDecimal local;
        if ("USD".equals(e.currency())|| (account!=null&&"Hong Kong".equals(account.country()))) local=usd;
        else local=usd.divide(fx.get().usdPerUnit(),2,RoundingMode.HALF_UP);
        String explanation="Annual USD list "+price.get().annualUsd()+" x "+e.qty()+" x 1 year"+(reinstate.signum()>0?" + 20% reinstatement":"")+"; FX "+("USD".equals(e.currency())?"1.00":fx.get().usdPerUnit().toPlainString());
        return new Models.Quote(e.currency(),local,usd,term,discount,reinstate,quoteSku,explanation,true);
    }

    public List<Models.Opportunity> opportunities() {
        LocalDate today=props.today()==null?LocalDate.now():props.today();
        LocalDate end=today.plusDays(90);
        List<Models.Opportunity> out=new ArrayList<>();
        for (var e:data.entitlements) {
            if (e.endDate().isBefore(today.minusDays(180))||e.endDate().isAfter(end)) continue;
            Models.Match m=match(e); Models.CrmAccount a=account(m.accountId());
            String status=interpretOrder(data.orders,e);
            List<String> flags=new ArrayList<>();
            if (m.accountId()==null) flags.add("UNMATCHED_CRM");
            if (m.confidence().equals("LOW")) flags.add("LOW_MATCH_CONFIDENCE");
            if (a!=null && "MERGED".equals(accountSource(a.accountId()).status())) flags.add("CRM_MERGED_TO_"+a.accountId());
            if (e.status().equals("EXPIRED")) flags.add("VENDOR_EXPIRED");
            long daysPast=ChronoUnit.DAYS.between(e.endDate(),today);
            if (daysPast>30&&daysPast<=180) flags.add("LAPSED_REINSTATEMENT");
            if (daysPast>180) flags.add("LAPSED_OVER_180");
            if ("LEGACY_PERPETUAL".equals(e.licenseModel())) flags.add("LEGACY_SUCCESSOR_REQUIRED");
            if (a!=null && "CHURNED".equals(a.status())) flags.add("CHURNED_DO_NOT_CHASE");
            if (status.equals("partially renewed")) flags.add("PARTIAL_RENEWAL_REVIEW");
            if (status.equals("in flight")) flags.add("IN_FLIGHT");
            data.orders.stream().filter(o->e.entId().equals(o.entId())&&"REJECTED".equals(o.status())).findAny().ifPresent(o->flags.add("ORDER_REJECTED"));
            Models.Quote q=status.equals("renewed")?new Models.Quote(e.currency(),BigDecimal.ZERO,BigDecimal.ZERO,12,BigDecimal.ZERO,BigDecimal.ZERO,"", "Already renewed by ACCEPTED order",false):quote(e,today);
            if (!q.quotable()) flags.add("CANNOT_QUOTE");
            long endGap=Math.abs(ChronoUnit.DAYS.between(e.endDate(),today.plusDays(90)));
            if (e.endDate().isBefore(today.plusDays(91))) flags.add("IN_DECEMBER_WINDOW");
            BigDecimal score=rankScore(e,status,q,a,today);
            String reason=rankReason(e,status,q,a,today);
            out.add(new Models.Opportunity(e.entId(),e.sku(),e.qty(),a!=null?a.name():e.customerName(),m.accountId(),
                    a!=null?a.owner():null,a!=null?a.segment():null,e.endDate(),status,m.method(),m.confidence(),flags,q,score,reason));
        }
        out.sort(Comparator.comparing(Models.Opportunity::rankingScore).reversed().thenComparing(Models.Opportunity::endDate));
        return out;
    }

    public List<Models.ChaseEntry> chaseList(){
        return opportunities().stream().filter(o->o.renewalStatus().equals("open")||o.renewalStatus().equals("in flight")||o.renewalStatus().equals("partially renewed"))
                .filter(o->o.quote().quotable()).filter(o->!o.flags().contains("CHURNED_DO_NOT_CHASE")&&!o.flags().contains("IN_FLIGHT")||o.flags().contains("IN_FLIGHT"))
                .limit(10).map(o->new Models.ChaseEntry(o.entId(),o.customerName(),o.sku(),o.qty(),o.endDate(),o.rankingScore(),o.rankingReason(),o.renewalStatus(),o.owner(),o.accountId())).toList();
    }

    private BigDecimal rankScore(Models.Entitlement e,String status,Models.Quote q,Models.CrmAccount a,LocalDate today){
        if (!q.quotable()||"renewed".equals(status)|| (a!=null&&"CHURNED".equals(a.status()))) return BigDecimal.ZERO;
        long days=Math.max(0,ChronoUnit.DAYS.between(today,e.endDate()));
        BigDecimal score=BigDecimal.valueOf(100-days).add(q.totalUsd().min(BigDecimal.valueOf(1000)).multiply(new BigDecimal("0.02")));
        if (a!=null) {if("ENT".equals(a.segment())) score=score.add(BigDecimal.valueOf(30));else if("MID".equals(a.segment())) score=score.add(BigDecimal.valueOf(15));}
        if (status.equals("in flight")) score=score.add(BigDecimal.valueOf(20));
        if (status.equals("partially renewed")) score=score.add(BigDecimal.valueOf(25));
        return score.setScale(2,RoundingMode.HALF_UP);
    }
    private String rankReason(Models.Entitlement e,String status,Models.Quote q,Models.CrmAccount a,LocalDate today){
        if (!q.quotable()) return "Cannot quote: "+q.explanation();
        if ("renewed".equals(status)) return "Already renewed; no chase needed.";
        long days=ChronoUnit.DAYS.between(today,e.endDate());
        String size=a==null?"unknown customer segment":a.segment()+" customer";
        return days<=90?("Expires in "+days+" days; "+size+"; "+status+"; USD "+q.totalUsd()+" quote"):("Outside immediate window; "+size+"; USD "+q.totalUsd()+" quote");
    }

    private Models.CrmAccount account(String id){ if(id==null)return null; return data.accounts.stream().filter(a->a.accountId().equals(id)).findFirst().orElse(null); }
    private Models.CrmAccount accountSource(String id){ if(id==null)return null; return data.accounts.stream().filter(a->a.accountId().equals(id)).findFirst().orElse(null); }
    private boolean active(Models.PriceRow p,LocalDate d){return !d.isBefore(p.effectiveFrom())&&(p.effectiveTo()==null||!d.isAfter(p.effectiveTo()));}
    private String successorSku(String sku,LocalDate d){var p=data.prices.stream().filter(x->x.sku().equals(sku)&&active(x,d)).findFirst();return p.flatMap(x->Optional.ofNullable(x.successorSku())).orElse(sku);}
    private Models.Quote unquotable(String c,String reason){return new Models.Quote(c,BigDecimal.ZERO,BigDecimal.ZERO,12,BigDecimal.ZERO,BigDecimal.ZERO,null,reason,false);}
    private static String normalize(String s){return s==null?"":s.toLowerCase().replaceAll("[^a-z0-9]","");}
}
