package com.infobahn.renewals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class RenewalsApplication {

    public static void main(String[] args) {
        SpringApplication.run(RenewalsApplication.class, args);
    }
}
