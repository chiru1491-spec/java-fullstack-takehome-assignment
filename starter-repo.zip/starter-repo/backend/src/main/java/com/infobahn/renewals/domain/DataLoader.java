package com.infobahn.renewals.domain;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infobahn.renewals.config.AppProperties;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.*;

@Component
public class DataLoader implements ApplicationRunner {
    private final AppProperties props;
    private final JdbcTemplate db;
    private final ObjectMapper json;

    public volatile List<Models.CrmAccount> accounts = List.of();
    public volatile List<Models.Entitlement> entitlements = List.of();
    public volatile List<Models.Order> orders = List.of();
    public volatile List<Models.PriceRow> prices = List.of();
    public volatile List<Models.FxRate> fx = List.of();

    public DataLoader(AppProperties props, JdbcTemplate db, ObjectMapper json) {
        this.props = props; this.db = db; this.json = json;
    }

    @Override public void run(ApplicationArguments args) throws Exception {
        Path dir = props.dataPath();
        accounts = loadAccounts(dir.resolve("crm_accounts.json"));
        entitlements = loadEntitlements(dir.resolve("vendor_entitlements.csv"));
        orders = loadOrders(dir.resolve("orders_log.csv"));
        prices = loadPrices(dir.resolve("price_book.csv"));
        fx = loadFx(dir.resolve("fx_rates.csv"));
        persist(dir);
    }

    private List<Models.CrmAccount> loadAccounts(Path f) throws IOException {
        List<Map<String,Object>> rows = json.readValue(f.toFile(), new TypeReference<>() {});
        List<Models.CrmAccount> out = new ArrayList<>();
        for (var r: rows) out.add(new Models.CrmAccount(s(r,"account_id"),s(r,"name"),s(r,"trading_name"),
                s(r,"country"),s(r,"email_domain"),s(r,"segment"),s(r,"owner"),s(r,"status"),
                s(r,"merged_into"),s(r,"vendor_account_no"),s(r,"notes")));
        return out;
    }

    private List<Models.Entitlement> loadEntitlements(Path f) throws IOException {
        var rows = csv(f); List<Models.Entitlement> out = new ArrayList<>();
        for (var r: rows) out.add(new Models.Entitlement(r.get("ent_id"),r.get("sku"),r.get("license_model"),
                Integer.parseInt(r.get("qty")),LocalDate.parse(r.get("start_date")),LocalDate.parse(r.get("end_date")),
                r.get("status"),r.get("end_customer_name"),r.get("end_customer_country"),r.get("vendor_account_no"),
                r.get("reseller"),r.get("contact_email"),r.get("currency"),decimal(r.get("last_unit_price_local"))));
        return out;
    }

    private List<Models.Order> loadOrders(Path f) throws IOException {
        var rows = csv(f); List<Models.Order> out = new ArrayList<>();
        for (var r: rows) out.add(new Models.Order(r.get("order_id"),LocalDate.parse(r.get("order_date")),
                r.get("crm_account_id"),empty(r.get("ent_id") ),r.get("sku"),Integer.parseInt(r.get("qty")),
                Integer.parseInt(r.get("term_months")),LocalDate.parse(r.get("new_start")),LocalDate.parse(r.get("new_end")),
                r.get("status"),r.get("notes")));
        return out;
    }

    private List<Models.PriceRow> loadPrices(Path f) throws IOException {
        var rows = csv(f); List<Models.PriceRow> out = new ArrayList<>();
        for (var r: rows) out.add(new Models.PriceRow(r.get("sku"),r.get("family"),r.get("license_model"),
                LocalDate.parse(r.get("effective_from")),empty(r.get("effective_to") ) == null ? null : LocalDate.parse(r.get("effective_to")),
                decimal(r.get("list_price_usd_annual")),empty(r.get("successor_sku"))));
        return out;
    }

    private List<Models.FxRate> loadFx(Path f) throws IOException {
        var rows = csv(f); List<Models.FxRate> out = new ArrayList<>();
        for (var r: rows) out.add(new Models.FxRate(r.get("month"),r.get("currency"),decimal(r.get("usd_per_unit"))));
        return out;
    }

    private void persist(Path dir) {
        db.update("DELETE FROM orders; DELETE FROM entitlements; DELETE FROM crm_accounts; DELETE FROM price_book; DELETE FROM fx_rates;");
        for (var a: accounts) db.update("INSERT INTO crm_accounts VALUES (?,?,?,?,?,?,?,?,?,?,?)",a.accountId(),a.name(),a.tradingName(),a.country(),a.emailDomain(),a.segment(),a.owner(),a.status(),a.mergedInto(),a.vendorAccountNo(),a.notes());
        for (var e: entitlements) db.update("INSERT INTO entitlements VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",e.entId(),e.sku(),e.licenseModel(),e.qty(),e.startDate(),e.endDate(),e.status(),e.customerName(),e.country(),e.vendorAccountNo(),e.reseller(),e.contactEmail(),e.currency(),e.lastUnitPrice());
        for (var o: orders) db.update("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?)",o.orderId(),o.orderDate(),o.crmAccountId(),o.entId(),o.sku(),o.qty(),o.termMonths(),o.newStart(),o.newEnd(),o.status(),o.notes());
        for (var p: prices) db.update("INSERT INTO price_book VALUES (?,?,?,?,?,?,?,?)",p.sku(),"",p.family(),p.licenseModel(),p.effectiveFrom(),p.effectiveTo(),p.annualUsd(),p.successorSku());
        for (var f: fx) db.update("INSERT INTO fx_rates VALUES (?,?,?)",f.month(),f.currency(),f.usdPerUnit());
    }

    static String s(Map<String,Object> r, String k) { Object v=r.get(k); return v==null?null:String.valueOf(v); }
    static String empty(String s) { return s==null||s.isBlank()?null:s.trim(); }
    static BigDecimal decimal(String s) { return s==null||s.isBlank()?null:new BigDecimal(s); }

    static List<Map<String,String>> csv(Path f) throws IOException {
        List<Map<String,String>> out = new ArrayList<>();
        try (BufferedReader br=Files.newBufferedReader(f,StandardCharsets.UTF_8)) {
            String[] h=parseCsv(br.readLine());
            String line;
            while ((line=br.readLine())!=null) { if(line.isBlank()) continue; String[] v=parseCsv(line); Map<String,String> m=new LinkedHashMap<>(); for(int i=0;i<h.length;i++) m.put(h[i],i<v.length?v[i]:""); out.add(m); }
        } return out;
    }
    static String[] parseCsv(String line) {
        List<String> out=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean quotes=false;
        for(int i=0;i<line.length();i++){ char c=line.charAt(i); if(c=='"'){if(quotes&&i+1<line.length()&&line.charAt(i+1)=='"'){b.append('"');i++;}else quotes=!quotes;}else if(c==','&&!quotes){out.add(b.toString().trim());b.setLength(0);}else b.append(c);} out.add(b.toString().trim()); return out.toArray(String[]::new);
    }
}
