package com.infobahn.renewals.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Models {
    public record CrmAccount(String accountId, String name, String tradingName, String country,
                             String emailDomain, String segment, String owner, String status,
                             String mergedInto, String vendorAccountNo, String notes) {}

    public record Entitlement(String entId, String sku, String licenseModel, int qty,
                              LocalDate startDate, LocalDate endDate, String status,
                              String customerName, String country, String vendorAccountNo,
                              String reseller, String contactEmail, String currency,
                              BigDecimal lastUnitPrice) {}

    public record Order(String orderId, LocalDate orderDate, String crmAccountId, String entId,
                        String sku, int qty, int termMonths, LocalDate newStart, LocalDate newEnd,
                        String status, String notes) {}

    public record PriceRow(String sku, String family, String licenseModel,
                           LocalDate effectiveFrom, LocalDate effectiveTo,
                           BigDecimal annualUsd, String successorSku) {}

    public record FxRate(String month, String currency, BigDecimal usdPerUnit) {}

    public record Match(String accountId, String accountName, String method, String confidence) {}

    public record Quote(String quoteCurrency, BigDecimal totalLocal, BigDecimal totalUsd,
                        Integer termMonths, BigDecimal discountPercent, BigDecimal reinstatementPercent,
                        String priceVersion, String explanation, boolean quotable) {}

    public record Opportunity(String entId, String sku, int qty, String customerName,
                              String accountId, String owner, String segment,
                              LocalDate endDate, String renewalStatus, String matchMethod,
                              String matchConfidence, List<String> flags, Quote quote,
                              BigDecimal rankingScore, String rankingReason) {}

    public record ChaseEntry(String entId, String customerName, String sku, int qty,
                             LocalDate endDate, BigDecimal score, String reason, String renewalStatus,
                             String owner, String accountId) {}
}
