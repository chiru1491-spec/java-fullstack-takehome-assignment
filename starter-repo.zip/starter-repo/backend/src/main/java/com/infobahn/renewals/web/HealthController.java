package com.infobahn.renewals.web;

import java.nio.file.Files;
import java.time.Clock;
import java.time.LocalDate;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infobahn.renewals.config.AppProperties;

/** Confirms the app, the database and the data folder are all wired up. Safe to delete later. */
@RestController
public class HealthController {

    private final Clock clock;
    private final JdbcTemplate jdbc;
    private final AppProperties props;

    public HealthController(Clock clock, JdbcTemplate jdbc, AppProperties props) {
        this.clock = clock;
        this.jdbc = jdbc;
        this.props = props;
    }

    @GetMapping("/api/health")
    public Map<String, Object> health() {
        Integer db = jdbc.queryForObject("SELECT 1", Integer.class);
        return Map.of(
                "status", "ok",
                "today", LocalDate.now(clock).toString(),
                "database", db != null && db == 1 ? "up" : "down",
                "dataDir", props.dataPath().toString(),
                "dataDirFound", Files.isDirectory(props.dataPath()));
    }
}
