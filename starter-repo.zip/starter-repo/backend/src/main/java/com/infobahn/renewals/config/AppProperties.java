package com.infobahn.renewals.config;

import java.nio.file.Path;
import java.time.LocalDate;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Settings under {@code app.*} in application.yml.
 *
 * @param today   the business date the app treats as "today"; null means the real system date
 * @param dataDir folder holding the five files from the data pack
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(LocalDate today, String dataDir) {

    // Kept as a String above: Spring's Path converter rejects relative paths like "../data".
    public Path dataPath() {
        return Path.of(dataDir).toAbsolutePath().normalize();
    }
}
